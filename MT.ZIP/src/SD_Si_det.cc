#include "SD_Si_det.hh"
#include "SD_Si_det_hit.hh"

#include <G4AutoLock.hh>
namespace {G4Mutex SD_Si_det_Mutex = G4MUTEX_INITIALIZER;}

SD_Si_det :: SD_Si_det (G4String SDname, G4String Fname[10]) : G4VSensitiveDetector(SDname) 
{
 G4AutoLock lock(SD_Si_det_Mutex);
 collectionName.insert("SD_Si_det_hitCollection");
 
 G4int i;
 for (i=0;i<10;i++)
 {
  hit_SD_Si_det[i].open(Fname[i],std::fstream::app);
//  G4cout<<Fname[i]<<" "<<G4endl;
 } 
 for (i=0; i<10; i++) {SumE[i]=0.;}
}

SD_Si_det :: ~SD_Si_det() {}

void SD_Si_det :: Initialize(G4HCofThisEvent* HCE)
{
 hitCollection = new SD_Si_det_hitCollection(GetName(), collectionName[0]);
 
 static G4int HCID=-1;
 if (HCID<0) HCID = GetCollectionID(0);
 HCE->AddHitsCollection(HCID,hitCollection);
}

extern G4int eventID;

void SD_Si_det :: EndOfEvent(G4HCofThisEvent*)
{
 G4AutoLock lock(SD_Si_det_Mutex);
 int thr=G4Threading::G4GetThreadId();
 for (G4int i=0; i<10; i++) 
 {hit_SD_Si_det[i] << std::setw(10) << this->GetSumE(i) << std::setw(10) << this->GetCopyNum(i) << " local thread=" << thr << G4endl;}
 for (G4int i=0; i<10; i++) 
 {SumE[i]=0.;}
}

G4bool SD_Si_det :: ProcessHits(G4Step* step, G4TouchableHistory* ROhist)
{
 G4TouchableHandle touchable = step->GetPreStepPoint()->GetTouchableHandle();
 G4int copyNo   = touchable->GetVolume(0)->GetCopyNo();
 G4double edep  = 0.;
 edep           = step->GetTotalEnergyDeposit();

 this->AddSumE(edep,copyNo);
 this->SetCopyNum(copyNo);
 
 SD_Si_det_hit *aHit = new SD_Si_det_hit();
 aHit->SetEdep(step->GetTotalEnergyDeposit());
 aHit->SetLayerNumber(step->GetPreStepPoint()->GetTouchableHandle()->GetVolume(0)->GetCopyNo());
 hitCollection->insert(aHit);
 
 return true; 
}

