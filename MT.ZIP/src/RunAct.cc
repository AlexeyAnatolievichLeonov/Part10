#include "RunAct.hh"

// ���������� ������� �� ������ Run - ����� �������-Event, ����� ����������
namespace {G4Mutex RunActMutex = G4MUTEX_INITIALIZER;}
RunAct::RunAct(std::ofstream& ofsa) 
{
 G4AutoLock lock(RunActMutex);
 this->f_act=&ofsa;
 (*f_act) << "Hi from RunAct!" << G4endl;
}

RunAct::~RunAct()
{
 G4AutoLock lock(RunActMutex);
 (*f_act) << "Bye from RunAct!" << G4endl;  
}

time_t Start, End;
int RunNum = 0;
G4double TotalEsum=0.;

G4Run* RunAct::GenerateRun()
{
 fMyRun = new MyRun();
 return fMyRun;
}

void RunAct::BeginOfRunAction(const G4Run* aRun) 
{
 G4cout << "\n---Start------ Run # "<<RunNum<<" --------\n" <<"RunId="<<aRun->GetRunID()<< G4endl;
 time(&Start);
}

void RunAct::EndOfRunAction(const G4Run* aRun) 
{
 G4AutoLock lock(RunActMutex);
 int thr=G4Threading::G4GetThreadId();
 time(&End);
 G4cout << " Time spent on this Run = " << difftime(End, Start)<<" seconds"<< G4endl;
 G4cout << "\n---Stop------ Run # "<<RunNum<<" --------\n" <<" RunId="<<aRun->GetRunID()<< " TotalEsum=" << TotalEsum << " local threading"<< thr 
        << " fMyRun " << fMyRun->Get_totalE() << G4endl;
 RunNum++;
 if (!IsMaster())
 {
  (*f_act) << "End Run " << thr << " TotalEsum=" << TotalEsum << " from MyRun=" << fMyRun->Get_totalE() << G4endl;
 }
 if (IsMaster())
 {
  (*f_act) << "End Run MASTER " << thr << " TotalEsum=" << TotalEsum << " from MyRun=" << fMyRun->Get_totalE() << G4endl;
 }
}

void RunAct::AddE_total(G4double edep)
{
 TotalEsum+=edep;
}

void RunAct::Add_totalE(G4double e)
{
 fMyRun->Add_totalE(e);
}
