#include "Loader.hh"
#include "Geometry.hh"
#include "Action.hh"
#include <G4Types.hh>
#include <globals.hh>

Loader::Loader(int argc, char **argv, std::ofstream& ofsa) 
{
 this->ofs_sn=&ofsa;
 (*ofs_sn) << std::setw(12) << "Hi from Loader!" << G4endl;

 CLHEP::HepRandom::setTheEngine(new CLHEP::RanecuEngine);
 CLHEP::HepRandom::setTheSeed(time(NULL));

#ifdef G4MULTITHREADED
 runManager = new G4MTRunManager;
// runManager->SetNumberOfThreads(G4Threading::G4GetNumberOfCores());
 runManager->SetNumberOfThreads(5);
#else
 runManager = new G4RunManager;
#endif
 G4VUserDetectorConstruction* realWorld = new Geometry(*this->ofs_sn);
 runManager->SetUserInitialization(realWorld);

 G4VModularPhysicsList* physicsList = new QBBC;
 physicsList->RegisterPhysics(new G4ParallelWorldPhysics("parallelWorld",true));

 runManager->SetUserInitialization(physicsList);
 runManager->SetUserInitialization(new Action(*this->ofs_sn));
 runManager->Initialize();
// Initialize visualization
 G4VisManager* visManager = new G4VisExecutive;
 visManager->Initialize();
 G4UImanager *UImanager = G4UImanager::GetUIpointer();

 if (argc != 1) 
 {
// batch mode
  G4String command = "/control/execute ";
  G4String fileName = argv[1];
  UImanager->ApplyCommand(command + fileName);
  G4String command1 = "/PrimaryPart/my_cmd";
  UImanager->ApplyCommand(command1);
 }
 else
 {
  G4UIExecutive *ui = new G4UIExecutive(argc, argv, "qt"); //Here we can redefine win32/qt interface
  UImanager->ApplyCommand("/control/execute vis.mac");
  ui->SessionStart();//and this two
  delete ui;
  }
 }

 Loader::~Loader()
 {
  delete runManager;
  delete visManager;
  (*ofs_sn) << std::setw(12) << "Bye from Loader!" << G4endl; 
 }
