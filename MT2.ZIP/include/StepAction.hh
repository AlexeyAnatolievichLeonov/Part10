//#ifndef M_DGW_4_STEPACTION_HH
//#define M_DGW_4_STEPACTION_HH

#include <G4UserSteppingAction.hh>
#include <G4Step.hh>
#include <fstream>
#include "string.h"

#include <G4AutoLock.hh>
namespace {G4Mutex StepMutex = G4MUTEX_INITIALIZER;}

class StepAct :public G4UserSteppingAction {
public:
        std::ofstream *f_step;

        StepAct(std::ofstream& ofsa)
        {
         this->f_step=&ofsa;
         (*f_step) << "Hi from Step!" << G4endl;
        };
        ~StepAct()
        {
         G4AutoLock lock(StepMutex);
         (*f_step) << "Bye from Step!" << G4endl;
        };	

	void UserSteppingAction(const G4Step*);
};

//#endif
