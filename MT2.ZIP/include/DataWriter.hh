#ifndef FINAL_DATAWRITER_HH
#define FINAL_DATAWRITER_HH

#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <globals.hh>
#include <G4String.hh>
#include <G4Types.hh>
#include <G4GlobalConfig.hh>

class OutFile{
private:

public:
    static std::ofstream fout;
    static void Open();
    static void Close();
    static void Info(G4String a);
};
#endif //FINAL_DATAWRITER_HH
