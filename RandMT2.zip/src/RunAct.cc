#include "RunAct.hh"

// ���������� ������� �� ������ Run - ����� �������-Event, ����� ����������

RunAct::RunAct(std::ofstream& ofsa) 
{
 this->f_act=&ofsa;
 (*f_act) << "Hi from RunAct!" << std::endl;
 
  // Register accumulable to the accumulable manager
  G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
  accumulableManager->RegisterAccumulable(total_dE);
}

RunAct::~RunAct()
{
 (*f_act) << "Bye from RunAct!" << std::endl;  
}

time_t Start, End;
int RunNum = 0;
G4double TotalEsum=0.;

void RunAct::BeginOfRunAction(const G4Run* aRun) 
{
 G4cout << "\n---Start------ Run # "<<RunNum<<" --------\n" <<"RunId="<<aRun->GetRunID()<< G4endl;
 time(&Start);

 std::string fileName="./random/run_current.rndm";
 G4UImanager *UImanager = G4UImanager::GetUIpointer();
 G4String command = "/random/resetEngineFrom ";
 UImanager->ApplyCommand(command + fileName);

 std::string fileName1="./random/run_act_file.rndm";
// CLHEP::HepRandom::getTheEngine()->restoreStatus(fileName.c_str());
 CLHEP::HepRandom::getTheEngine()->saveStatus(fileName1.c_str());

// G4RunManager::GetRunManager()->SetRandomNumberStoreDir("./random");
// G4RunManager::GetRunManager()->SetRandomNumberStore(true);

}

void RunAct::EndOfRunAction(const G4Run* aRun) 
{
// Merge accumulables
 G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
 accumulableManager->Merge();
  
 int thr=G4Threading::G4GetThreadId();
 time(&End);
 G4cout << " Time spent on this Run = " << difftime(End, Start)<<" seconds"<< G4endl;
 G4cout << "\n---Stop------ Run # "<<RunNum<<" --------\n" <<" RunId="<<aRun->GetRunID()<< " TotalEsum=" << TotalEsum << " local threading"<< thr << G4endl;
 RunNum++;
 if (!IsMaster())
 {
  (*f_act) << std::setw(12) << "End Run " << thr << " TotalEsum=" << TotalEsum << " localRun=" << total_dE.GetValue() << std::endl;
 }
 if (IsMaster())
 {
  (*f_act) << std::setw(12) << "End Run MASTER " << thr << " TotalEsum=" << TotalEsum <<  " localRun=" << total_dE.GetValue() << std::endl;
 }
}

void RunAct::AddE_total(G4double edep)
{
 TotalEsum+=edep;
}

void RunAct::Add_totalE(G4double edep)
{
 total_dE+=edep;
}

G4double RunAct::Get_totalE()
{
 return total_dE.GetValue();
}

