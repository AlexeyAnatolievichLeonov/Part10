#include "MyRunManager.hh"

using namespace std;

MyRunManager::MyRunManager():G4MTRunManager () {}
MyRunManager::~MyRunManager() {}
