//#pragma once

#ifndef RunAct_hh
#define RunAct_hh

#include <G4UserRunAction.hh>
#include <G4AccumulableManager.hh>
#include <G4Run.hh>
#include <G4RunManager.hh>
#include <G4MTRunManager.hh>
#include <G4Threading.hh>
#include <G4UImanager.hh>
#include "globals.hh"
#include <ctime>
#include <fstream>

class RunAct : public G4UserRunAction 
{
 public:
	RunAct(std::ofstream& ofsa);
	 ~RunAct();
	std::ofstream *f_act;

        void Add_totalE(G4double e);
        G4double Get_totalE();
	void BeginOfRunAction(const G4Run*);
	void EndOfRunAction(const G4Run*);

  static void AddE_total(G4double dE);
 private:
         G4Accumulable<G4double> total_dE=0.;
};

#endif
