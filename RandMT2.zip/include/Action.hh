#ifndef FINAL_ACTION_HH
#define FINAL_ACTION_HH

#include <G4VUserActionInitialization.hh>
#include <DataWriter.hh>
#include <StepAction.hh>
#include <PrimaryPart.hh>
#include <EventAct.hh>
#include <RunAct.hh>
#include <iomanip>

class Action: public G4VUserActionInitialization
{
 public:
  std::ofstream* f_act;
 public:Action(std::ofstream&);
~Action();
 virtual void Build() const;
 virtual void BuildForMaster() const;
};
#endif
