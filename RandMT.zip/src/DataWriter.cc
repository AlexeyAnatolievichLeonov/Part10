#include <DataWriter.hh>

std::ofstream OutFile::fout;
void OutFile::Open()
{
 fout.open("info.txt");
}
void OutFile::Close(){fout.close();}
void OutFile::Info(G4String a){fout << a << G4endl;}
