#pragma once

#ifndef MyRunManager_hh
#define MyRunManager_hh

#include <G4MTRunManager.hh>
#include <G4RNGHelper.hh>

class MyRunManager : public G4MTRunManager 
{
 public:
  MyRunManager();
  ~MyRunManager() override;
};
#endif

